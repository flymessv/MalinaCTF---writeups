import random, zlib, marshal

def main():
    SEED = int(input("Введите SEED: ").strip())
    ENCRYPTED = bytes.fromhex(input("Введите ENCRYPTED (IN HEX !!!!!!!!!!!!!!! HEX !!!!!!!!!!): ").strip())

    random.seed(SEED)
    key = bytes(random.randrange(256) for _ in range(len(ENCRYPTED)))
    decompressed = zlib.decompress(bytes(e ^ k for e, k in zip(ENCRYPTED, key)))
    original = marshal.loads(decompressed)

    print("\nПолученный флаг:")
    print(original.decode())

if __name__ == "__main__":
    main()
